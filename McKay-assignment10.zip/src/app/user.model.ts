export class User {

    id : string;
    name: string;
    email: string;
    contact: string;

    constructor(id: string, name: string, email: string, contact: string,)
    {
        this.id = "",
        this.name = "",
        this.email = "",
        this.contact = ""
    }
}

