export const environment = {
  production: false,
  firebaseConfig: {
    apiKey: "AIzaSyDlJ_n9Jy6UWrpVv2kIHEg9qVW7cARvhvs",
    authDomain: "firestore-crud-be185.firebaseapp.com",
    projectId: "firestore-crud-be185",
    storageBucket: "firestore-crud-be185.appspot.com",
    messagingSenderId: "500971308675",
    appId: "1:500971308675:web:75b3225923a7169951fdb6",
  }
};