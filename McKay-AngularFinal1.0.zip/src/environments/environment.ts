// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebaseConfig: {
  apiKey: "AIzaSyDYch_fyscEYhjz8GvvpDRr8WI3-sliW2E",
  authDomain: "wellness-journal-76595.firebaseapp.com",
  projectId: "wellness-journal-76595",
  storageBucket: "wellness-journal-76595.appspot.com",
  messagingSenderId: "203824400017",
  appId: "1:203824400017:web:ebf719a2148d8a92d12130",
  measurementId: "G-5NTB0TTRDE"
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
